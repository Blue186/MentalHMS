create view view_studentinfo_sno_spwd as
select `test1`.`studentinfo`.`SNo` AS `SNo`, `test1`.`studentinfo`.`SPwd` AS `SPwd`
from `test1`.`studentinfo`;

