create view view_student_evalute_show as
select `test1`.`tevalute`.`TENo`     AS `TENo`,
       `test1`.`tevalute`.`Evalute`  AS `Evalute`,
       `test1`.`tevalute`.`TETime`   AS `TETime`,
       `test1`.`tevalute`.`TAno`     AS `TAno`,
       `test1`.`teacherinfo`.`TName` AS `TName`,
       `test1`.`tevalute`.`SNo`      AS `SNo`,
       `test1`.`tevalute`.`TNo`      AS `TNo`
from (`test1`.`tevalute`
         join `test1`.`teacherinfo` on ((`test1`.`tevalute`.`TNo` = `test1`.`teacherinfo`.`TNo`)));

