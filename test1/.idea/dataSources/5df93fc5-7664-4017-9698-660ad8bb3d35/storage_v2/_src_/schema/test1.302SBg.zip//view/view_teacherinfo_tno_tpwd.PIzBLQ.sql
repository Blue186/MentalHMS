create view view_teacherinfo_tno_tpwd as
select `test1`.`teacherinfo`.`TNo` AS `TNo`, `test1`.`teacherinfo`.`TPwd` AS `TPwd`
from `test1`.`teacherinfo`;

