create view view_studentinfo_show as
select `test1`.`studentinfo`.`SNo`      AS `SNo`,
       `test1`.`studentinfo`.`SName`    AS `SName`,
       `test1`.`studentinfo`.`Birth`    AS `Birth`,
       `test1`.`studentinfo`.`SPNo`     AS `SPNo`,
       `test1`.`studentinfo`.`Major`    AS `Major`,
       `test1`.`studentinfo`.`Grade`    AS `Grade`,
       `test1`.`instructorinfo`.`IName` AS `IName`,
       `test1`.`studentinfo`.`SPwd`     AS `SPwd`
from (`test1`.`studentinfo`
         join `test1`.`instructorinfo`
              on ((`test1`.`studentinfo`.`SInstructor` = `test1`.`instructorinfo`.`SInstructor`)));

