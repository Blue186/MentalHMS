create view view_student_show_ask as
select `test1`.`sask`.`SNo`          AS `SNo`,
       `test1`.`sask`.`SAInfo`       AS `SAInfo`,
       `test1`.`sask`.`Time`         AS `Time`,
       `test1`.`sask`.`Ano`          AS `Ano`,
       `test1`.`teacherinfo`.`TName` AS `TName`,
       `test1`.`sask`.`SANo`         AS `SANo`,
       `test1`.`sask`.`TAnswer`      AS `TAnswer`
from (`test1`.`sask`
         join `test1`.`teacherinfo` on ((`test1`.`sask`.`TNo` = `test1`.`teacherinfo`.`TNo`)));

