create view view_question_teacher as
select `test1`.`questions`.`Questions`  AS `Questions`,
       `test1`.`questions`.`QRNo`       AS `QRNo`,
       `test1`.`questions`.`QAnswer`    AS `QAnswer`,
       `test1`.`qtype_study`.`Question` AS `Question`
from (`test1`.`questions`
         join `test1`.`qtype_study` on ((`test1`.`questions`.`QNum` = `test1`.`qtype_study`.`QNum`)));

