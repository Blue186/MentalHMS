create definer = root@localhost view view_studentinfo_show as
select `test`.`studentinfo`.`SNo`      AS `SNo`,
       `test`.`studentinfo`.`SName`    AS `SName`,
       `test`.`studentinfo`.`Birth`    AS `Birth`,
       `test`.`studentinfo`.`SPNo`     AS `SPNo`,
       `test`.`studentinfo`.`Major`    AS `Major`,
       `test`.`studentinfo`.`Grade`    AS `Grade`,
       `test`.`instructorinfo`.`IName` AS `IName`,
       `test`.`studentinfo`.`SPwd`     AS `SPwd`
from (`test`.`studentinfo`
         join `test`.`instructorinfo`
              on ((`test`.`studentinfo`.`SInstructor` = `test`.`instructorinfo`.`SInstructor`)));

