create definer = root@localhost view view_student_evalute_show as
select `test`.`tevalute`.`TENo`     AS `TENo`,
       `test`.`tevalute`.`Evalute`  AS `Evalute`,
       `test`.`tevalute`.`TETime`   AS `TETime`,
       `test`.`tevalute`.`TAno`     AS `TAno`,
       `test`.`teacherinfo`.`TName` AS `TName`,
       `test`.`tevalute`.`SNo`      AS `SNo`,
       `test`.`tevalute`.`TNo`      AS `TNo`
from (`test`.`tevalute`
         join `test`.`teacherinfo` on ((`test`.`tevalute`.`TNo` = `test`.`teacherinfo`.`TNo`)));

