create definer = root@localhost view view_studentinfo_sno_spwd as
select `test`.`studentinfo`.`SNo` AS `SNo`, `test`.`studentinfo`.`SPwd` AS `SPwd`
from `test`.`studentinfo`;

