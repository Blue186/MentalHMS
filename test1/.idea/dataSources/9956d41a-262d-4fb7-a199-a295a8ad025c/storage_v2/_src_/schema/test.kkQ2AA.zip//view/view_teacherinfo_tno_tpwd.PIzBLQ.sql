create definer = root@localhost view view_teacherinfo_tno_tpwd as
select `test`.`teacherinfo`.`TNo` AS `TNo`, `test`.`teacherinfo`.`TPwd` AS `TPwd`
from `test`.`teacherinfo`;

