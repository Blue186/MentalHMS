create definer = root@localhost view view_student_show_ask as
select `test`.`sask`.`SNo`          AS `SNo`,
       `test`.`sask`.`SAInfo`       AS `SAInfo`,
       `test`.`sask`.`Time`         AS `Time`,
       `test`.`sask`.`Ano`          AS `Ano`,
       `test`.`teacherinfo`.`TName` AS `TName`,
       `test`.`sask`.`SANo`         AS `SANo`,
       `test`.`sask`.`TAnswer`      AS `TAnswer`
from (`test`.`sask`
         join `test`.`teacherinfo` on ((`test`.`sask`.`TNo` = `test`.`teacherinfo`.`TNo`)));

