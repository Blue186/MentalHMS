create definer = root@localhost view view_question_result_show as
select `test`.`qtype`.`Type`        AS `Type`,
       `test`.`qresult`.`QREva`     AS `QREva`,
       `test`.`qresult`.`QGrade`    AS `QGrade`,
       `test`.`qresult`.`QRNo`      AS `QRNo`,
       `test`.`studentinfo`.`SName` AS `SName`,
       `test`.`teacherinfo`.`TName` AS `TName`
from (((`test`.`qtype` join `test`.`qresult` on ((`test`.`qresult`.`QNo` = `test`.`qtype`.`QNo`))) join `test`.`studentinfo` on ((`test`.`qresult`.`SNo` = `test`.`studentinfo`.`SNo`)))
         join `test`.`teacherinfo` on ((`test`.`qresult`.`TNo` = `test`.`teacherinfo`.`TNo`)));

